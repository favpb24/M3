# Importar
from flask import Flask, render_template, request, send_from_directory


app = Flask(__name__)

# Resultados del formulario
@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        # obtener la imagen seleccionada
        selected_image = request.form.get('image-selector')

        # Asignación #2. Recepción del texto
        text_top = request.form.get("text.Top")
        text_bottom = request.form.get("textBottom")

        
       

        # Asignación #3. Recepción del posicionamiento del texto
        text_bottom_position = request.form.get("textBottomPosition")
        text_top_position = request.form.get("textTopPosition")

        return render_template('index.html', 
                               # Visualización de la imagen seleccionada
                               selected_image=selected_image,


                               # Asignación #2. Visualización del texto
                               text_bottom = text_bottom,
                               text_top = text_top,

                               #  Asignación #3. Visualización del color
                                 selected_color = request.form.get("color-selector"),
                               
                               # Asignación #3. Visualización de la posición del texto
                                 text_bottom_position = text_bottom_position,
                                text_top_position = text_top_position

                               )
    else:
        # Mostrar la primera imagen por defecto
        return render_template('index.html', selected_image='logo.svg')


@app.route('/static/img/<path:path>')
def serve_images(path):
    return send_from_directory('static/img', path)

app.run(debug=True)
