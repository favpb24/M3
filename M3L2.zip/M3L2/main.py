import time
import subprocess
import webbrowser
from flask import Flask, render_template

app = Flask(__name__)

# Función de cálculo
def result_calculate(size, lights, device):
    home_coef = 100
    light_coef = 0.04
    devices_coef = 5   
    return size * home_coef + lights * light_coef + device * devices_coef 

# Primera página
@app.route('/')
def index():
    return render_template('index.html')

# Segunda página
@app.route('/<size>')
def lights(size):
    return render_template('lights.html', size=size)

# Tercera página
@app.route('/<size>/<lights>')
def electronics(size, lights):
    return render_template('electronics.html', size=size, lights=lights)

# Página final con el cálculo
@app.route('/<size>/<lights>/<device>')
def end(size, lights, device):
    return render_template(
        'end.html', 
        result=result_calculate(int(size), int(lights), int(device))
    )

if __name__ == "__main__":
    # Espera un segundo para que Flask se inicie y abre Google Chrome
    time.sleep(1)
    subprocess.Popen(["open", "-a", "Google Chrome", "http://127.0.0.1:5000"])
    app.run(debug=True)
